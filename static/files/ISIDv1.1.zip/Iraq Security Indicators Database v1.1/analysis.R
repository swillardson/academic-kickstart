library(foreign)
setwd("C:/Users/Political Science/Dropbox/Current Projects/Detainee Database Paper/Iraq Security Indicators Database v1.1")

iraq <-read.dta("iraq_detainee_indicatorsv1.1.dta", convert.dates=TRUE,
         convert.factors=TRUE, missing.type=FALSE)

model1 <- lm(iraqi_civ_death ~ us_troop_level+izsoldier+sunni+shia, 

iraq.ratio <- read.csv("ratio.csv",header=TRUE)


cp1 <- cpt.var(iraq.ratio$ratio2,method="PELT", Q=4)
plot(cp1)
